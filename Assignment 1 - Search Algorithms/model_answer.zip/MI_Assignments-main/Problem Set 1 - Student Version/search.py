from problem import HeuristicFunction, Problem, S, A, Solution
from collections import deque
from helpers import utils

# TODO: Import any modules you want to use

# All search functions take a problem and a state
# If it is an informed search function, it will also receive a heuristic function
# S and A are used for generic typing where S represents the state type and A represents the action type

# All the search functions should return one of two possible type:
# 1. A list of actions which represent the path from the initial state to the final state
# 2. None if there is no solution


def BreadthFirstSearch(problem: Problem[S, A], initial_state: S) -> Solution:
    # TODO: ADD YOUR CODE HERE
    # states waiting to be explored
    frontier = deque([initial_state])
    # set of all explored states states so far inorder not to repeat the future
    explored = set({})
    # dictionary to the store the actions path from the initia state to the current state
    # key is the state itself value is the list of actions from the intial state to this state
    actionsTree = dict({initial_state: list([])})
    while len(frontier) > 0:
        parentState = frontier.popleft()
        # check if the reached state is goal state directly after retriving it from the frontier
        if problem.is_goal(parentState):
            return actionsTree[parentState]
        explored.add(parentState)
        # expantion step
        tempActions = problem.get_actions(parentState)
        # loop over all possible actions for the current state
        for action in tempActions:
            childState = problem.get_successor(parentState, action)
            if childState not in explored and childState not in frontier:
                # only add a state to the frontier if it is not explored or been added before (don't repeat history)
                frontier.append(childState)
                # copy the path (actions) of your parent state
                temp = actionsTree[parentState].copy()
                # append the path (action) from your parent state to yourself
                temp.append(action)
                actionsTree[childState] = temp
    else:
        # return none if no solution is found
        return None


def DepthFirstSearch(problem: Problem[S, A], initial_state: S) -> Solution:
    # TODO: ADD YOUR CODE HERE
    frontier = deque([initial_state])
    # set of all explored states states so far inorder not to repeat the future
    explored = set({})
    # dictionary to the store the actions path from the initia state to the current state
    # key is the state itself value is the list of actions from the intial state to this state
    actionsTree = dict({initial_state: list([])})
    while len(frontier) > 0:
        parentState = frontier.pop()
        if problem.is_goal(parentState):
            return actionsTree[parentState]
        tempActions = problem.get_actions(parentState)
        explored.add(parentState)
        for action in tempActions:
            childState = problem.get_successor(parentState, action)
            if childState not in frontier and childState not in explored:
                frontier.append(childState)
                # copy the path (actions) of your parent state
                temp = actionsTree[parentState].copy()
                # append the path (action) from your parent state to yourself
                temp.append(action)
                actionsTree[childState] = temp
    else:
        return None


def UniformCostSearch(problem: Problem[S, A], initial_state: S) -> Solution:
    # TODO: ADD YOUR CODE HERE
    # states waiting to be explored
    frontier = dict({initial_state: 0.0})
    # set of all explored states states so far inorder not to repeat the future
    explored = set({})
    # dictionary to the store the actions path from the initia state to the current state
    # key is the state itself value is the list of actions from the intial state to this state
    actionsTree = dict({initial_state: list([])})
    while len(frontier) > 0:
        # get the first state (has lowest path cost)
        parentState = list(frontier.keys())[0]
        parentCost = frontier[parentState]
        # remove the state form the frontier
        frontier.pop(parentState)
        if problem.is_goal(parentState):
            return actionsTree[parentState]
        explored.add(parentState)
        # expantion step
        tempActions = problem.get_actions(parentState)
        for action in tempActions:
            childState = problem.get_successor(parentState, action)
            # calculate action cost
            actionCost = problem.get_cost(
                parentState, action) + parentCost
            if (childState not in explored and childState not in frontier) or (childState in frontier and actionCost < frontier[childState]):
                # add a state to the frontier if it is not explored or been added before (don't repeat history)
                # or it exits in the frontier with higher path cost
                frontier[childState] = actionCost
                # after adding element sort the frontier again according the path cost
                frontier = dict(
                    sorted(frontier.items(), key=lambda item: item[1]))
                # copy the path (actions) of your parent state
                temp = actionsTree[parentState].copy()
                # append the path (action) from your parent state to yourself
                temp.append(action)
                actionsTree[childState] = temp
    else:
        # return none if no solution is found
        return None


def AStarSearch(problem: Problem[S, A], initial_state: S, heuristic: HeuristicFunction) -> Solution:
    # TODO: ADD YOUR CODE HERE
    # states waiting to be explored
    frontier = dict({initial_state: 0.0})
    # set of all explored states states so far inorder not to repeat the future
    explored = set({})
    # dictionary to the store the actions path from the initia state to the current state
    # key is the state itself value is the list of actions from the intial state to this state
    actionsTree = dict({initial_state: list([])})
    while len(frontier) > 0:
        # get the first state (has lowest path cost)
        parentState = list(frontier.keys())[0]
        parentCost = frontier[parentState]
        # remove the state form the frontier
        frontier.pop(parentState)
        if problem.is_goal(parentState):
            return actionsTree[parentState]
        explored.add(parentState)
        # expantion step
        tempActions = problem.get_actions(parentState)
        for action in tempActions:
            childState = problem.get_successor(parentState, action)
            # calculate action cost
            actionCost = problem.get_cost(
                parentState, action) + parentCost
            if (childState not in explored and childState not in frontier) or (childState in frontier and actionCost+heuristic(problem, childState) < frontier[childState]+heuristic(problem, childState)):
                # add a state to the frontier if it is not explored or been added before (don't repeat history)
                # or it exits in the frontier with higher path cost
                frontier[childState] = actionCost
                # after adding element sort the frontier again according the path cost
                frontier = dict(
                    sorted(frontier.items(), key=lambda item: item[1]+heuristic(problem, item[0])))
                # copy the path (actions) of your parent state
                temp = actionsTree[parentState].copy()
                # append the path (action) from your parent state to yourself
                temp.append(action)
                actionsTree[childState] = temp
    else:
        # return none if no solution is found
        return None


def BestFirstSearch(problem: Problem[S, A], initial_state: S, heuristic: HeuristicFunction) -> Solution:
    # TODO: ADD YOUR CODE HERE
    # states waiting to be explored
    frontier = dict({initial_state: 0.0})
    # set of all explored states states so far inorder not to repeat the future
    explored = set({})
    # dictionary to the store the actions path from the initia state to the current state
    # key is the state itself value is the list of actions from the intial state to this state
    actionsTree = dict({initial_state: list([])})
    while len(frontier) > 0:
        # get the first state (has lowest path cost)
        parentState = list(frontier.keys())[0]
        # remove the state form the frontier
        frontier.pop(parentState)
        if problem.is_goal(parentState):
            return actionsTree[parentState]
        explored.add(parentState)
        # expantion step
        tempActions = problem.get_actions(parentState)
        for action in tempActions:
            childState = problem.get_successor(parentState, action)
            # calculate action cost
            actionCost = heuristic(problem, childState)
            if (childState not in explored and childState not in frontier) or (childState in frontier and actionCost < frontier[childState]):
                # add a state to the frontier if it is not explored or been added before (don't repeat history)
                # or it exits in the frontier with higher path cost
                frontier[childState] = actionCost
                # after adding element sort the frontier again according the path cost
                frontier = dict(
                    sorted(frontier.items(), key=lambda item: item[1]))
                # copy the path (actions) of your parent state
                temp = actionsTree[parentState].copy()
                # append the path (action) from your parent state to yourself
                temp.append(action)
                actionsTree[childState] = temp
    else:
        # return none if no solution is found
        return None
